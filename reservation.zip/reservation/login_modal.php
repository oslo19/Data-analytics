<div id="login" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title center"><i class = "fa fa-key"></i> Log in</h4>
        </div>
         <div class="modal-body">
                            <div class="padd">
                  <!-- Login form -->
                  <form class="form-horizontal">
                    <!-- Email -->
                    <div class="form-group">
                      <label class="control-label col-lg-3" for="inputEmail">Email</label>
                      <div class="col-lg-7">
                        <input type="text" class="form-control" id="inputEmail" placeholder="Email">
                      </div>
                    </div>
                    <!-- Password -->
                    <div class="form-group">
                      <label class="control-label col-lg-3" for="inputPassword">Password</label>
                      <div class="col-lg-7">
                        <input type="password" class="form-control" id="inputPassword" placeholder="Password">
                      </div>
                    </div>                    
                       <div class="form-group">
                      <label class="control-label col-lg-3" for="inputPassword"></label>
                      <div class="col-lg-7">
                        <button class = "btn btn-success btn-block">Login</button> 
                      </div>
                    </div> 
                    <br />
                  </form>
				  
				</div>
        </div>
        <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
		</div>
    </div>
</div>