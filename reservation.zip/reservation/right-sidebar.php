<div class = "col-md-3 col-lg-3 inquiry hideme">
					<div class = "widget">
            <div class = "widget-head">
              Check Inquiry Status
            </div>
            <div class = "widget-content">
              <div class = "padd">
                <form class="form-horizontal" role="form" method="post" action="search.php">
                                <div class="form-group">
                                  <div class="col-lg-10 col-lg-offset-1">
                                    <input type ="text" name="rcode" class="form-control" placeholder="Reservation Code">
                                  </div>
                                </div>
                <div class="form-group">
                                  <div class="col-lg-offset-1 col-lg-10">
                                    <button type="submit" class="btn btn-sm btn-success btn-block">Search</button>                                  
                                  </div>
                                </div>
                              </form>
            </div>
            </div>
          </div>    
				</div>

        <div class="col-md-3 col-lg-3 hideme">
              <!-- Widget -->
              <div class="widget">
                <!-- Widget title -->
                <div class="widget-head">
                  <div class="pull-left">Contact Information</div>
                   
                  <div class="clearfix"></div>
                </div>
                <div class="widget-content">
                  <!-- Widget content -->
                  <div class="padd">
                                               <!-- Contact box -->
                             <div class="support-contact">
                                <!-- Phone, email and address with font awesome icon -->
                                
                                <p><i class="fa fa-phone"></i>&nbsp; Phone<strong>:</strong> 09056306212</p>
                                <hr />
                                <p><i class="fa fa-envelope"></i>&nbsp; Email<strong>:</strong> estellitacateringservices@gmail.com</p>
                                <hr />
                                <p><i class="fa fa-home"></i>&nbsp; Address<strong>:</strong> Minglanilla Cebu </p>
                <hr />
        <p><i class="fa fa-facebook"></i>&nbsp; Facebook<strong>:</strong> facebook.com/estellitacateringserivces </p>
                <hr />              
                                <!-- Button -->
                              
                             </div>
                  </div>
                </div>

              </div> 

            </div>
      </div>  
    </div>
    </div>