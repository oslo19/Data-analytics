<?php session_start();
if(empty($_SESSION['id'])):
header('Location:index.php');
endif;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - <?php include('../includes/title.php');?></title>
  <?php include('../includes/links.php');?>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>

<div class="navbar navbar-fixed-top bs-docs-nav" role="banner">
  <div class="container">
    <?php include('../includes/topbar.php');?>
  </div>
</div>

<!-- Main content starts -->
<div class="content" style="margin-top:10px">
    <?php include('../includes/sidebar.php');?>

    <div class="mainbar">
      <div class="page-head">
        <h2 class="pull-left"><i class="fa fa-home"></i> Dashboard</h2>
      </div>

      <!-- Pie Chart Container -->
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="widget">
              <div class="widget-head">
                <h4 class="pull-left">Sales and Reservation Report</h4>
                <div class="clearfix"></div>
              </div>
              <div class="widget-content">
                <canvas id="myChart" width="400" height="400"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<!-- Footer starts -->
<?php include('../includes/footer.php');?>

<!-- Footer ends -->
<?php include('../includes/js.php');?>

  <script type="text/javascript">
  const data = {
    labels: ['Total Sales', 'Pending Reservations', 'Approved Reservations', 'Finished Reservations'],
    datasets: [{
      label: 'Sales and Reservations',
      data: [],   
      backgroundColor: [
        'rgb(255, 99, 132)', // Blue for Total Sales
        'rgb(255, 205, 86)', // Yellow for Pending Reservations
       'rgb(54, 162, 235)', // Green for Approved Reservations
      ],
      hoverOffset: 4
    }]
  };

  const config = {
    type: 'pie',
    data: data,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        tooltip: {
          callbacks: {
            label: function(tooltipItem) {
              return `${data.labels[tooltipItem.dataIndex]}: ${data.datasets[0].data[tooltipItem.dataIndex]}`;
            }
          }
        }
      }
    }
  };

  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );

  function loadPieChart() {
  var dateRange = $('#dateRange').val(); // Get selected date range

  $.getJSON("data_combined.php?range=" + dateRange, function(response) {
    console.log("Response from data_combined.php:", response);  

    // Access totals from the response JSON
    const totals = response.totals.data;



    // Update chart labels and data
    myChart.data.labels = ['Total Sales',  'Approved Reservations', 'Finished Reservations'];
    myChart.data.datasets[0].data = [
            totals['Total Sales'],
            totals['Approved Reservations'],
            totals['Finished Reservations']
        ];
    // Update the chart
    myChart.update();
  });
}


  $(document).ready(function() {
    loadPieChart(); // Load the chart data when the page loads
  });
  </script>


</body>
</html>
