<?php
session_start();
include('../includes/dbcon.php');

$range = isset($_GET['range']) ? $_GET['range'] : 'monthly'; // Get range from query string
$year = date("Y");
$category = array();
$series1 = array();
$series1['name'] = ucfirst($range) . ' Sales';

switch ($range) {
    case 'yearly':
        // Fetch yearly data (group by year)
        $query = mysqli_query($con, "SELECT YEAR(payment_date) as year, SUM(amount) as amount 
            FROM payment 
            GROUP BY YEAR(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = $r['year'];
            $series1['data'][] = $r['amount'];
        }
        break;

    case 'monthly':
        // Fetch monthly data (group by month in the current year)
        $query = mysqli_query($con, "SELECT DATE_FORMAT(payment_date, '%b') as month, SUM(amount) as amount 
            FROM payment 
            WHERE YEAR(payment_date) = '$year' 
            GROUP BY MONTH(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = $r['month'];
            $series1['data'][] = $r['amount'];
        }
        break;

    case 'weekly':
        // Fetch weekly data (group by week number in the current year)
        $query = mysqli_query($con, "SELECT WEEK(payment_date) as week, SUM(amount) as amount 
            FROM payment 
            WHERE YEAR(payment_date) = '$year' 
            GROUP BY WEEK(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = 'Week ' . $r['week'];
            $series1['data'][] = $r['amount'];
        }
        break;

    case 'daily':
        // Fetch daily data (group by day in the current year)
        $query = mysqli_query($con, "SELECT DATE_FORMAT(payment_date, '%d-%b-%Y') as day, SUM(amount) as amount 
            FROM payment 
            WHERE YEAR(payment_date) = '$year' 
            GROUP BY DAY(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = $r['day'];
            $series1['data'][] = $r['amount'];
        }
        break;
}

$result = array();
array_push($result, $category);
array_push($result, $series1);

echo json_encode($result, JSON_NUMERIC_CHECK);
mysqli_close($con);
?>
