<?php
session_start();
include('../includes/dbcon.php');

$range = isset($_GET['range']) ? $_GET['range'] : 'monthly'; // Get the selected range from the query string
$year1 = date("Y");
$category = array();
$series1 = array();
$series1['name'] = 'Approved and Finished';

switch ($range) {
    case 'yearly':
        // Fetch yearly reservation data
        $query = mysqli_query($con, "SELECT YEAR(r_date) as year, COUNT(*) as count 
            FROM reservation 
            WHERE r_status IN ('Finished', 'Approved') 
            GROUP BY YEAR(r_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = $r['year'];
            $series1['data'][] = $r['count'];
        }
        break;

    case 'monthly':
        // Fetch monthly reservation data
        $query = mysqli_query($con, "SELECT DATE_FORMAT(r_date, '%b') as month, COUNT(*) as count 
            FROM reservation 
            WHERE YEAR(r_date) = '$year1' 
            AND r_status IN ('Finished', 'Approved') 
            GROUP BY MONTH(r_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = $r['month'];
            $series1['data'][] = $r['count'];
        }
        break;

    case 'weekly':
        // Fetch weekly reservation data
        $query = mysqli_query($con, "SELECT WEEK(r_date) as week, COUNT(*) as count 
            FROM reservation 
            WHERE YEAR(r_date) = '$year1' 
            AND r_status IN ('Finished', 'Approved') 
            GROUP BY WEEK(r_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $category['name'][] = 'Week ' . $r['week'];
            $series1['data'][] = $r['count'];
        }
        break;

		case 'daily':
			// Fetch daily reservation data with full date
			$query = mysqli_query($con, "SELECT DATE_FORMAT(r_date, '%d-%b-%Y') as day, COUNT(*) as count 
				FROM reservation 
				WHERE YEAR(r_date) = '$year1' 
				AND r_status IN ('Finished', 'Approved') 
				GROUP BY r_date") or die(mysqli_error($con));
			while ($r = mysqli_fetch_array($query)) {
				$category['name'][] = $r['day'];
				$series1['data'][] = $r['count'];
			}
			break;
		
}

$result = array();
array_push($result, $category);
array_push($result, $series1);

echo json_encode($result, JSON_NUMERIC_CHECK);
mysqli_close($con);
?>
