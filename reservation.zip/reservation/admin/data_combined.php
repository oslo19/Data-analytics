<?php
session_start();
include('../includes/dbcon.php');

$range = isset($_GET['range']) ? $_GET['range'] : 'monthly';
$year = date("Y");

// Initialize arrays for categories and series
$salesCategory = array();
$reserveCategory = array();

// Prepare series data for sales and reservations
$salesSeries = array();
$salesSeries['name'] = ucfirst($range) . ' Sales';

$reserveSeries = array();
$reserveSeries['name'] = 'Approved and Finished Reservations';

// Query for Sales Data
switch ($range) {
    case 'yearly':
        $query = mysqli_query($con, "SELECT YEAR(payment_date) as year, SUM(amount) as amount 
            FROM payment 
            GROUP BY YEAR(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $salesCategory['name'][] = $r['year'];
            $salesSeries['data'][] = $r['amount'];
        }
        break;

    case 'monthly':
        $query = mysqli_query($con, "SELECT DATE_FORMAT(payment_date, '%b') as month, SUM(amount) as amount 
            FROM payment 
            WHERE YEAR(payment_date) = '$year' 
            GROUP BY MONTH(payment_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $salesCategory['name'][] = $r['month'];
            $salesSeries['data'][] = $r['amount'];
        }
        break;

    // Additional cases for 'weekly' and 'daily' can be added similarly...
}

// Query for Reservation Data
switch ($range) {
    case 'yearly':
        $query = mysqli_query($con, "SELECT YEAR(r_date) as year, COUNT(*) as count 
            FROM reservation 
            WHERE r_status IN ('Finished', 'Approved') 
            GROUP BY YEAR(r_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $reserveCategory['name'][] = $r['year'];
            $reserveSeries['data'][] = $r['count'];
        }
        break;

    case 'monthly':
        $query = mysqli_query($con, "SELECT DATE_FORMAT(r_date, '%b') as month, COUNT(*) as count 
            FROM reservation 
            WHERE YEAR(r_date) = '$year' 
            AND r_status IN ('Finished', 'Approved') 
            GROUP BY MONTH(r_date)") or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($query)) {
            $reserveCategory['name'][] = $r['month'];
            $reserveSeries['data'][] = $r['count'];
        }
        break;

    // Additional cases for 'weekly' and 'daily'...
}

// Totals for Pending, Approved, and Finished Reservations
$pendingCountQuery = mysqli_query($con, "SELECT COUNT(*) as pending_count FROM reservation WHERE r_status='Pending'") or die(mysqli_error($con));
$approvedCountQuery = mysqli_query($con, "SELECT COUNT(*) as approved_count FROM reservation WHERE r_status='Approved'") or die(mysqli_error($con));
$finishedCountQuery = mysqli_query($con, "SELECT COUNT(*) as finished_count FROM reservation WHERE r_status='Finished'") or die(mysqli_error($con));

$pendingCount = mysqli_fetch_assoc($pendingCountQuery)['pending_count'];
$approvedCount = mysqli_fetch_assoc($approvedCountQuery)['approved_count'];
$finishedCount = mysqli_fetch_assoc($finishedCountQuery)['finished_count'];

// Total Sales
$totalSalesQuery = mysqli_query($con, "SELECT SUM(amount) as total_sales FROM payment") or die(mysqli_error($con));
$totalSales = mysqli_fetch_assoc($totalSalesQuery)['total_sales'];

// Prepare the result array
$result = array();
array_push($result, $salesCategory, $salesSeries, $reserveCategory, $reserveSeries);

// Add totals data for chart pie input
$totals = array(
    'name' => 'Reservations Summary',
    'data' => array(
        'Total Sales' => $totalSales,
        'Approved Reservations' => $approvedCount,
        'Finished Reservations' => $finishedCount
    )
);

$result['totals'] = $totals;

// Output the result as JSON
echo json_encode($result, JSON_NUMERIC_CHECK);
mysqli_close($con);
?>
